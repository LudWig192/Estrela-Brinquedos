import React from 'react';
import  '../src/App.css';
import Sidebar from './Components/Sidebar';
import Inputs from './Components/Inputs';
import Tabela from './Components/Tabela';

function App() {
  return (
    <div>
      <Sidebar />
      <Inputs />
      <Tabela />
    </div>
  );
}

export default App;
