//Contato
import React from "react";
import FuncionarioCadastro from "../Components/FuncionarioCad";

const Funcionarios = () => {
  return (
    <>
      <div>
        <h2>Página funcionario</h2>
        <FuncionarioCadastro />
      </div>
    </>
  );
};

export default Funcionarios;
