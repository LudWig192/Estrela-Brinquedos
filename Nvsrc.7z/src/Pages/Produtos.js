import React from "react";

function Produtos ()    {
    return (
        <h1>PRODUTOS</h1>
    )
}

export default Produtos;