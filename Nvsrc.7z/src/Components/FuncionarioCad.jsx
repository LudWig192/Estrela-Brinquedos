// FuncionarioCad.jsx
import React, { useState, useEffect } from "react";
import axios from 'axios';

const FuncionarioCad = () => {
    const [funcionarios, setFuncionarios] = useState([]);
    const [formData, setFormData] = useState({
        nome: '',
        codcracha: '',
        cargo: '',
        senha: '',
    });

    useEffect(() => {
        const fetchData = async () => {
            try {
                const { data } = await axios.get("http://localhost:3001/Funcionarios");
                setFuncionarios(data);
            } catch (error) {
                console.error("Erro ao buscar usuários:", error); // Adiciona este log de erro
            }
        };
        fetchData();
    }, []);

    const handleExcluirUsuario = async (id) => {
        try {
            await axios.delete(`http://localhost:3001/Funcionarios/${id}`);
            // Atualiza a lista de cadastros após a exclusão
            const { data } = await axios.get("http://localhost:3001/Funcionarios");
            setFuncionarios(data);
            console.log("Usuário excluído com sucesso!");
        } catch (error) {
            console.error("Erro ao excluir usuário:", error);
        }
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await axios.post('http://localhost:3001/Funcionarios', formData);
            alert('Cadastro criado com sucesso!');
            // Limpar o formulário após o envio bem-sucedido
            setFormData({
                nome: '',
                codcracha: '',
                cargo: '',
                senha: '',
            });
            const { data } = await axios.get("http://localhost:3001/Funcionarios");
            setFuncionarios(data);
        } catch (error) {
            console.error('Erro ao criar cadastro:', error);
            alert('Erro ao criar cadastro. Verifique o console para mais detalhes.');
        }
    };

    return (
        <>
            <form onSubmit={handleSubmit}>
                <input type="text" name="nome" placeholder="Nome " value={formData.nome} onChange={handleChange} />
                <input type="int" name="codcracha" placeholder="codcracha " value={formData.codcracha} onChange={handleChange} />
                <input type="texto" name="cargo" placeholder="cargo" value={formData.cargo} onChange={handleChange} />
                <input type="password" name="senha" placeholder="senha " value={formData.senha} onChange={handleChange} />
                <button type="submit">Salvar</button>
            </form>
            <div>
                <table border={2} cellPadding={5} cellSpacing={5}>
                    <thead>
                        <tr>
                            <th>Nome</th>
                            <th>codigo Cracha</th>
                            <th>cargo</th>
                            <th>senha</th>
                            {/* Adicione mais colunas, se necessário */}
                        </tr>
                    </thead>
                    <tbody>
                        {funcionarios.map((funcionario) => (
                            <tr key={funcionario.id}>
                                <td>{funcionario.nome}</td>
                                <td>{funcionario.codcracha}</td>
                                <td>{funcionario.cargo}</td>
                                <td>{funcionario.senha}</td>
                                <td>
                                    <button
                                        variant="danger"
                                        onClick={() => handleExcluirUsuario(funcionario.id)} >
                                        Excluir
                                    </button>
                                </td>
                                {/* Renderizar outras colunas, se necessário */}
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </>
    );
};

export default FuncionarioCad;
