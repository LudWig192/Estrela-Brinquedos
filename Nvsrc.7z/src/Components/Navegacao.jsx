import React from 'react';
import { Link } from 'react-router-dom';

const Header = () => {
  return (
    <header>
      <nav>
        <ul>
          <li>
            <Link to="/">Home</Link>
          </li>
          <li>
            <Link to="/Funcionarios">Funcionario</Link>
          </li>
          <li>
            <Link to="/clientes">Clientes</Link>
          </li>
          <li>
            <Link to="/Produtos">Produtos e Serviços</Link>
          </li>
        </ul>
      </nav>
    </header>
  );
};

export default Header;
