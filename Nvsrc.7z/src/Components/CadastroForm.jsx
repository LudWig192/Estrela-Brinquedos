// CadastroForm.jsx
import React, { useState, useEffect } from "react";
import axios from 'axios';

const CadastroForm = () => {
  const [clientes, setClientes] = useState([]);
  const [formData, setFormData] = useState({
    nome: '',
    telefone: '',
    dataNascimento: '',
    cpf: '',
    email: '',
    cep: '',
  });
  
  useEffect(() => {
    const fetchData = async () => {
      try {
        const { data } = await axios.get("http://localhost:3001/clientes");
        setClientes(data);
      } catch (error) {
        console.error("Erro ao buscar usuários:", error); // Adiciona este log de erro
      }
    };
    fetchData();
  }, []);

  const handleExcluirUsuario = async (id) => {
    try {
      await axios.delete(`http://localhost:3001/clientes/${id}`);
      // Atualiza a lista de cadastros após a exclusão
      const { data } = await axios.get("http://localhost:3001/clientes");
      setClientes(data);
      console.log("Usuário excluído com sucesso!");
    } catch (error) {
      console.error("Erro ao excluir usuário:", error);
    }
  };
  

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:3001/clientes', formData);
      alert('Cadastro criado com sucesso!');
      // Limpar o formulário após o envio bem-sucedido
      setFormData({
        nome: '',
        telefone: '',
        dataNascimento: '',
        cpf: '',
        email: '',
        cep: '',
      });
      const { data } = await axios.get("http://localhost:3001/clientes");
      setClientes(data);
    } catch (error) {
      console.error('Erro ao criar cadastro:', error);
      alert('Erro ao criar cadastro. Verifique o console para mais detalhes.');
    }
  };

  return (
    <>
      <form onSubmit={handleSubmit}>
        <input type="text" name="nome" placeholder="Nome " value={formData.nome} onChange={handleChange} />
        <input type="tel" name="telefone" placeholder="telefone " value={formData.telefone} onChange={handleChange} />
        <input type="date" name="datanascimento" placeholder="dataNascimento" value={formData.datanasciemento} onChange={handleChange} />
        <input type="number" name="cpf" placeholder="CPF " value={formData.cpf} onChange={handleChange} />
        <input type="email" name="email" placeholder="email " value={formData.email} onChange={handleChange} />
        <input type="number" name="cep" placeholder="cep " value={formData.cep} onChange={handleChange} />
        <button type="submit">Salvar</button>
      </form>
      <div>
        <table border={2} cellPadding={5} cellSpacing={5}>
          <thead>
            <tr>
              <th>Nome</th>
              <th>telefone</th>
              <th>datanascimento</th>
              <th>cpf</th>
              <th>email</th>
              <th>cep</th>
              {/* Adicione mais colunas, se necessário */}
            </tr>
          </thead>
          <tbody>
            {clientes.map((cliente) => (
              <tr key={cliente.id}>
                <td>{cliente.nome}</td>
                <td>{cliente.telefone}</td>
                <td>{cliente.datanasciemento}</td>
                <td>{cliente.cpf}</td>
                <td>{cliente.email}</td>
                <td>{cliente.cep}</td>
                <td>
                  <button
                    variant="danger"
                    onClick={() => handleExcluirUsuario(cliente.id)} >
                    Excluir
                  </button>
                </td>
                {/* Renderizar outras colunas, se necessário */}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
};

export default CadastroForm;
