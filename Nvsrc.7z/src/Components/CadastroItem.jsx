import React from 'react';

const ClientesItem = ({ clientes, onDelete }) => {
  return (
    <tr>
      <td>{clientes.id}</td>
      <td>{clientes.nome}</td>
      <td>{clientes.telefone}</td>
      <td>{clientes.datanasciemento}</td>
      <td>{clientes. cpf}</td>
      <td>{clientes.email}</td>
      <td>{clientes.cep}</td>
      <td>
        <button onClick={() => onDelete(clientes.id)}>Excluir</button>
      </td>
    </tr>
  );
};

export default ClientesItem;