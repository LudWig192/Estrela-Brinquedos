import React from 'react';

const FuncionariosItem = ({ funcionarios, onDelete }) => {
  return (
    <tr>
      <td>{funcionarios.id}</td>
      <td>{funcionarios.nome}</td>
      <td>{funcionarios.telefone}</td>
      <td>{funcionarios.datanasciemento}</td>
      <td>{funcionarios. cpf}</td>
      <td>{funcionarios.email}</td>
      <td>{funcionarios.cep}</td>
      <td>
        <button onClick={() => onDelete(funcionarios.id)}>Excluir</button>
      </td>
    </tr>
  );
};

export default FuncionariosItem;