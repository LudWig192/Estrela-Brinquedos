import React from "react";
import {Routes, Route} from "react-router-dom";
import Home from "./Pages/Home";
import Funcionarios from "./Pages/Funcionarios";
import Clientes from "./Pages/Clientes";
import Produtos from "./Pages/Produtos";
import Faturas from "./Pages/Faturas";
import Registro from "./Pages/Registro_Vendas";

const Rotas = () => {
  return (
    <>
      <Routes>
        <Route path="/" exact element={<Home />} />
        <Route path="/Funcionarios" element={<Funcionarios />} />
        <Route path="/Clientes" element={<Clientes />} />
        <Route path="/Produtos" element={<Produtos />} />
        <Route path="/Faturas" element={<Faturas />} />
        <Route path="/Registro" element={<Registro />} />
      </Routes>
    </>
  );
};

export default Rotas;
