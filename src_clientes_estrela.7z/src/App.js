import React from 'react';
import '../src/App.css';
import Sidebar1 from './Components/Sidebar1';
import Tabela from './Components/Tabela';
import Inputs from './Components/inputs';

function App() {
  return (
    <div>
      <Inputs />
      <Sidebar1 />
      <Tabela />

    </div>
  );
}

export default App;
