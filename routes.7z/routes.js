const express = require('express');
const connection = require('./db');
const router = express.Router();

// ROTAS DE CLIENTES
// Rota para listar todos os registros
router.get('/clientes', (req, res) => {
  connection.query('SELECT * FROM cadastroclientes', (err, results) => {
    if (err) {
      console.error('Erro ao buscar os registros:', err);
      res.status(500).json({ error: 'Erro ao buscar os registros' });
      return;
    }
    res.json(results);
  });
});

// Rota para buscar um registro específico pelo ID
router.get('/clientes/:id', (req, res) => {
  const { id } = req.params;
  connection.query('SELECT * FROM cadastroclientes WHERE id = ?', [id], (err, results) => {
    if (err) {
      console.error('Erro ao buscar o registro:', err);
      res.status(500).json({ error: 'Erro ao buscar o registro' });
      return;
    }
    if (results.length === 0) {
      res.status(404).json({ error: 'Registro não encontrado' });
      return;
    }
    res.json(results[0]);
  });
});

// Rota para criar um novo registro
router.post('/clientes', (req, res) => {
  const { nome, telefone, datanascimento, cpf, email, cep, } = req.body;
  connection.query('INSERT INTO cadastroclientes (nome, telefone, datanascimento, cpf, email, cep) VALUES (?, ?, ?, ?, ?, ?)',
    [nome, telefone, datanascimento, cpf, email, cep], (err, result) => {
      if (err) {
        console.error('Erro ao criar o registro:', err);
        res.status(500).json({ error: 'Erro ao criar o registro' });
        return;
      }
      res.status(201).json({ message: 'Registro criado com sucesso', id: result.insertId });
    });
});

// Rota para atualizar um registro existente pelo ID
router.put('/clientes/:id', (req, res) => {
  const { id } = req.params;
  const { nome, email, cpf, idade, telefone, } = req.body;
  connection.query('UPDATE cadastroclientes SET nome = ?, email = ?, cpf = ?, idade = ?, telefone = ?,  WHERE id = ?',
    [nome, email, cpf, idade, telefone, id], (err, result) => {
      if (err) {
        console.error('Erro ao atualizar o registro:', err);
        res.status(500).json({ error: 'Erro ao atualizar o registro' });
        return;
      }
      res.json({ message: 'Registro atualizado com sucesso' });
    });
});

// Rota para excluir um registro pelo ID
router.delete('/clientes/:id', (req, res) => {
  const { id } = req.params;
  connection.query('DELETE FROM cadastroclientes WHERE id = ?', [id], (err, result) => {
    if (err) {
      console.error('Erro ao excluir o registro:', err);
      res.status(500).json({ error: 'Erro ao excluir o registro' });
      return;
    }
    res.json({ message: 'Registro excluído com sucesso' });
  });
});

// ROTAS DE FUNCIONARIOS
// Rota para listar todos os registros
router.get('/funcionarios', (req, res) => {
  connection.query('SELECT * FROM cadastrofuncionarios', (err, results) => {
    if (err) {
      console.error('Erro ao buscar os registros:', err);
      res.status(500).json({ error: 'Erro ao buscar os registros' });
      return;
    }
    res.json(results);
  });
});

// Rota para buscar um registro específico pelo ID
router.get('/funcionarios/:id', (req, res) => {
  const { id } = req.params;
  connection.query('SELECT * FROM cadastrofuncionarios WHERE id = ?', [id], (err, results) => {
    if (err) {
      console.error('Erro ao buscar o registro:', err);
      res.status(500).json({ error: 'Erro ao buscar o registro' });
      return;
    }
    if (results.length === 0) {
      res.status(404).json({ error: 'Registro não encontrado' });
      return;
    }
    res.json(results[0]);
  });
});

// Rota para criar um novo registro
router.post('/funcionario', (req, res) => {
  const { nome, codCracha, cargo, senha} = req.body;
  connection.query ;('INSERT INTO cadastrofuncionarios (nome, codCracha, cargo, senha) VALUES (?, ?, ?, ?)',

    [nome, codCracha, cargo, senha],
    
    (err, result) => {
      if (err) {
        console.error('Erro ao criar o registro:', err);
        res.status(500).json({ error: 'Erro ao criar o registro' });
        return;
      }
      res.status(201).json({ message: 'Registro criado com sucesso', id: result.insertId });
    });
});

// Rota para atualizar um registro existente pelo ID
router.put('/funcionarios/:id', (req, res) => {
  const { id } = req.params;
  const { nome, codCracha, cargo, senha } = req.body;
  connection.query('UPDATE cadastrofuncionario SET nome = ?, email = ?, cpf = ?, idade = ?, telefone = ?,  WHERE id = ?',
    [nome, email, cpf, idade, telefone, id], (err, result) => {
      if (err) {
        console.error('Erro ao atualizar o registro:', err);
        res.status(500).json({ error: 'Erro ao atualizar o registro' });
        return;
      }
      res.json({ message: 'Registro atualizado com sucesso' });
    });
});

// Rota para excluir um registro pelo ID
router.delete('/funcionario/:id', (req, res) => {
  const { id } = req.params;
  connection.query('DELETE FROM cadastrofuncionarios WHERE id = ?', [id], (err, result) => {
    if (err) {
      console.error('Erro ao excluir o registro:', err);
      res.status(500).json({ error: 'Erro ao excluir o registro' });
      return;
    }
    res.json({ message: 'Registro excluído com sucesso' });
  });
});

module.exports = router;
