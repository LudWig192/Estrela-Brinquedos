import React from 'react';
import '../src/App.css';
import NavBar from './Components/Sidebar';
import Tabelinha from './Components/Tabelinha';
import Inputs1 from './Components/Inputs';

function App() {
  return (
    <>
      <NavBar />
      <Inputs1 />
      <Tabelinha />

    </>
  );
}

export default App;
