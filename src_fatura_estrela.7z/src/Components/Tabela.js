import React from 'react';

function TabelaPreduh() {
    return (
        <div className="table-container">
            <table className="simple-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nome</th>
                        <th>Idade</th>
                        <th>Email</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>Bolsonaro</td>
                        <td>69</td>
                        <td>bolsonaro.brasil@gmail.com</td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>Will Smith</td>
                        <td>55</td>
                        <td>willsmith@gmail.com</td>
                    </tr>
                    <tr>
                        <td>3</td>
                        <td>Adolfinho</td>
                        <td>56</td>
                        <td>Adolfin.hitla@gmail.com</td>
                    </tr>

                </tbody>
            </table>
        </div>
    );
}

export default TabelaPreduh;
