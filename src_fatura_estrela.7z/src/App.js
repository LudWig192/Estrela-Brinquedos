// import logo from './logo.svg';
import './App.css';
import Inputs from './Components/Inputs';
import Sidebar from './Components/Sidebar';
import Tabela from './Components/Tabela';

function App() {
  return (
    <>
      <Sidebar />
      <Inputs />
      <Tabela />
    </>
  );
}

export default App;
