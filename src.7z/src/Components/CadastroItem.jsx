import React from 'react';

const ClientesItem = ({ Clientes, onDelete }) => {
  return (
    <tr>
      <td>{Clientes.id}</td>
      <td>{Clientes.nome}</td>
      <td>{Clientes.email}</td>
      <td>{Clientes.cpf}</td>
      <td>{Clientes. idade}</td>
      <td>{Clientes.telefone}</td>

      <td>
        <button onClick={() => onDelete(Clientes.id)}>Excluir</button>
      </td>
    </tr>
  );
};

export default ClientesItem;