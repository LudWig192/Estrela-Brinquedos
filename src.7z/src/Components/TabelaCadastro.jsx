import React, { useState, useEffect } from "react";
import axios from "axios";

const TabelaFuncionamentos = () => {
  const [clientes, setClientes] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const { data } = await axios.get("http://localhost:3001/cadastros");
        setClientes(data);
      } catch (error) {
        console.error("Erro ao buscar usuários:", error); // Adiciona este log de erro
      }
    };

    fetchData();
  }, []);

  const handleExcluirUsuario = async (idCadastro) => {
    try {
      await axios.delete(`http://localhost:3001/cadastros/${idCadastro}`);
      // Atualiza a lista de cadastros após a exclusão
      const { data } = await axios.get("http://localhost:3001/cadastros");
      setClientes(data);
      console.log("Usuário excluído com sucesso!");
    } catch (error) {
      console.error("Erro ao excluir usuário:", error);
    }
  };

  return (

    <div>
      <table border={2} cellPadding={5} cellSpacing={5}>
        <thead>
          <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>Email</th>
            <th>CPF</th>
            <th>Idade</th>
            <th>Telefone</th>
            {/* Adicione mais colunas, se necessário */}
          </tr>
        </thead>
        <tbody>
          {clientes.map((clientes) => (
            <tr key={clientes.idClientes}>
              <td>{clientes.idClientes}</td>
              <td>{clientes.Nome}</td>
              <td>{clientes.email}</td>
              <td>{clientes.cpf}</td>
              <td>{clientes.Idade}</td>
              <td>{clientes.telefone}</td>
              <td>
                <button
                  variant="danger"
                  onClick={() => handleExcluirUsuario(clientes.idClientes)} >
                  Excluir
                </button>
              </td>
              {/* Renderizar outras colunas, se necessário */}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default TabelaFuncionamentos;