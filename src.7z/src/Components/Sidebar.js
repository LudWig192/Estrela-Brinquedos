import React from 'react';
import {Link} from "react-router-dom;"
function Sidebar() {
  return (
    <div className="sidebar">
      <div className="sidebar-header">
    Gerenciamento de dados
      </div>
      <ul className="sidebar-menu">
        <li className="dropdown">
          <a href="#">Funcionários</a>
          <ul className="dropdown-menu">
            <Link to="/"></Link>
            <li><a href="/funcionarios/cadastro">Cadastro Funcionários</a></li>
            <li><a href="/funcionarios/login">Login Funcionários</a></li>
          </ul>
        </li>
        <li className="dropdown">
          <a href="#">Clientes</a>
          <ul className="dropdown-menu">
            <li><a href="/clientes/cadastro-fornecedores">Cadastro Fornecedores</a></li>
            <li><a href="/clientes/cadastro-clientes">Cadastro Clientes</a></li>
            <li><a href="/clientes/historico-compras">Histórico de Compras (Clientes)</a></li>
          </ul>
        </li>
        <li className="dropdown">
          <a href="#">Produtos e Serviços</a>
          <ul className="dropdown-menu">
            <li><a href="/produtos-servicos/cadastro">Cadastro de Produtos e Serviços</a></li>
            <li><a href="/produtos-servicos/estoque">Estoque</a></li>
          </ul>
        </li>
        <li><a href="/faturas">Faturas</a></li>
        <li><a href="/registro-vendas">Registro de Vendas</a></li>
      </ul>
    </div>
  );
}

export default Sidebar;