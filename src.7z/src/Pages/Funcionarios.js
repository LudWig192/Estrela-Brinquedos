//Contato
import React from "react";
import TableFuncionario from "../Components/TabelaFuncionarios";

const Funcionarios = () => {
  return (
    <>
      <div>
        <h2>Página Contato</h2>
        <TableFuncionario />
      </div>
    </>
  );
};

export default Funcionarios;
