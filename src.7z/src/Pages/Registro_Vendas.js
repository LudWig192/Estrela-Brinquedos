import React from "react";

function Vendas ()    {
    return (
        <h1>REGISTRO DE VENDAS</h1>
    )
}

export default Vendas;