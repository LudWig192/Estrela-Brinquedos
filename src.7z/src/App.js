import logo from './logo.svg';
import './App.css';
// import Nav from './Components/Navbar';
import TabelaERP from './Components/Sidebar';

function App() {
  return (

    <TabelaERP />

  );
}

export default App;
