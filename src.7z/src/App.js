import React from 'react';

import '../src/App.css';

import { Route, BrowserRouter } from "react-router-dom";

import NavBar from './Components/Sidebar';
import Tabelinha from './Components/Tabelinha';
import Inputs1 from './Components/Inputs';

const Routes = () => {
  return (
    <BrowserRouter>
           <Route component = { Home }  path="/" exact />
           <Route component = { Sobre }  path="/sobre" />
           <Route component = { Usuario }  path="/usuario" />
       </BrowserRouter>
  )
}

function App() {
  return (
    <>
      <NavBar />
      <Inputs1 />
      <Tabelinha />

    </>
  );
}

export default App;
