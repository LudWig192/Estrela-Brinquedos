// import logo from './logo.svg';
import './App.css';
import Sidebar from './Components/Sidebar';
import Tabela from './Components/Tabela';
import Input from './Components/Input';

function App() {
  return (
    <>
      < Sidebar />
      <Input />
      <Tabela />
    </>
  );
}

export default App;
